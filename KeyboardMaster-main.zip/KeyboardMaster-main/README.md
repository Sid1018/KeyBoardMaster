# KeyboardMaster
A Keyboard Master Game Project using HTML, CSS and JAVASCRIPT with source code.



Download the given file ".html" and open it on any platform

Simply, run the given code.

DONE :)
